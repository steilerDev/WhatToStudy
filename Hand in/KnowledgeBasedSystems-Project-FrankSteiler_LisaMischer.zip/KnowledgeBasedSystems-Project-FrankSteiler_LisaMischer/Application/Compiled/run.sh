java -Djava.library.path=./Libraries/ -jar ./WhatToStudy.jar $*
